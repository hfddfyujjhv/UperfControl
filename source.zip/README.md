# Uperf Control

Uperf 模块的专用图形控制面板，替代 Scene 的核心调度功能。轻量、无广告、纯本地。

## 功能

| 模块 | 说明 |
|---|---|
| 模式切换 | 省电 / 均衡 / 性能 / 极速 / 狂暴 五档一键切换，底层调用 `/data/powercfg.sh` |
| 实时监控 | CPU 各核频率、CPU 负载、GPU 频率、电池温度，1 秒刷新 |
| 应用配置 | 给指定 App 绑定固定性能模式，写入 `perapp_powermode.txt` |
| 悬浮窗 | 游戏内浮窗显示 模式 / CPU / GPU / 温度，可拖动 |
| Turbo Boost | 手动触发模块内置的 `turbo_boost.sh` 极限调优 |

## 前置条件

1. 已刷入 **Uperf Game Turbo**（或 Uperf Game Turbo X）模块并重启
2. 已 root（Magisk / KernelSU / APatch）
3. 首次使用悬浮窗需授予「显示在其他应用上层」权限

## 工作原理

- 切模式：`sh /data/powercfg.sh <mode>`（mode ∈ powersave/balance/performance/fast/pedestal）
- 读状态：`/sdcard/Android/yc/uperf/cur_powermode.txt`
- 接口发现：解析 `/data/powercfg.json` 的 `entry` / `state` / `features` 字段
- 监控：root 读取 `/sys` 下 CPU/GPU 频率与 thermal_zone 温度
- root 交互：基于 [libsu](https://github.com/topjohnwu/libsu)

## 编译

### 方式一：Android Studio

1. 用 Android Studio 打开本项目根目录
2. 等待 Gradle Sync 完成（会自动下载依赖）
3. `Build → Build APK(s)` 或直接 `Run`

要求：Android Studio 版本 ≥ Hedgehog，JDK 17。

### 方式二：命令行

```bash
# 需要本机已安装 JDK 17 + Android SDK（ANDROID_HOME 指向 SDK 目录）
./gradlew assembleDebug
# 产物在 app/build/outputs/apk/debug/app-debug.apk
```

若本机没有 gradlew，可用本机 gradle 替代：

```bash
gradle assembleDebug
```

## 技术栈

- Kotlin + Jetpack Compose (Material3)
- libsu 5.2.2（root shell）
- Kotlin Coroutines + StateFlow（异步监控）

## 目录结构

```
app/src/main/java/com/uperf/control/
├── MainActivity.kt          # 入口 + 底部导航
├── root/RootShell.kt        # root shell 封装
├── core/
│   ├── PowerModeManager.kt  # 模式管理（powercfg 解析/切换）
│   ├── MonitorManager.kt    # 监控（CPU/GPU/温度）
│   └── PerAppManager.kt     # per-app 配置
├── ui/
│   ├── MainViewModel.kt     # 状态管理
│   ├── ModeScreen.kt        # 模式切换页
│   ├── MonitorScreen.kt     # 监控页
│   ├── PerAppScreen.kt      # 应用配置页
│   └── SettingsScreen.kt    # 设置页
└── overlay/OverlayService.kt # 悬浮窗服务
```
