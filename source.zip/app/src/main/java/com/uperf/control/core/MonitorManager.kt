package com.uperf.control.core

import com.uperf.control.root.RootShell
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** 单个 CPU 核频率 */
data class CpuCoreFreq(val core: Int, val freqKHz: Long)

/** 监控快照 */
data class MonitorSnapshot(
    val cpuFreqs: List<CpuCoreFreq>,
    val cpuLoad: Int,
    val gpuFreqMHz: Long,
    val temperatureC: Float,
)

/**
 * 监控管理器：读取 CPU/GPU 频率、负载、温度。
 */
object MonitorManager {

    private val _snapshot = MutableStateFlow(MonitorSnapshot(emptyList(), 0, 0, 0f))
    val snapshot: StateFlow<MonitorSnapshot> = _snapshot.asStateFlow()

    private var lastCpuTotal = 0L
    private var lastCpuIdle = 0L

    /** 采集一次监控数据 */
    suspend fun poll() {
        val cpuFreqs = readCpuFreqs()
        val cpuLoad = readCpuLoad()
        val gpuFreq = readGpuFreq()
        val temp = readTemperature()
        _snapshot.value = MonitorSnapshot(cpuFreqs, cpuLoad, gpuFreq, temp)
    }

    /** CPU 各核当前频率（kHz） */
    private suspend fun readCpuFreqs(): List<CpuCoreFreq> {
        val cores = listCores()
        if (cores.isEmpty()) return emptyList()
        val paths = cores.map { "/sys/devices/system/cpu/cpu$it/cpufreq/scaling_cur_freq" }
        val values = RootShell.readFiles(paths)
        return cores.mapIndexed { i, core ->
            val khz = values[paths[i]]?.toLongOrNull() ?: 0L
            CpuCoreFreq(core, khz)
        }
    }

    /** 已上线的 CPU 核编号 */
    private suspend fun listCores(): List<Int> {
        val out = RootShell.exec("ls /sys/devices/system/cpu/ | grep -E '^cpu[0-9]+$'")
        return out.lines().mapNotNull { line ->
            line.trim().removePrefix("cpu").toIntOrNull()
        }.sorted()
    }

    /** CPU 负载百分比（两次 /proc/stat 采样差值） */
    private suspend fun readCpuLoad(): Int {
        val stat = RootShell.readFile("/proc/stat")
        val cpuLine = stat.lines().firstOrNull { it.startsWith("cpu ") } ?: return 0
        val parts = cpuLine.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (parts.size < 4) return 0
        val idle = parts[3] + (parts.getOrNull(4) ?: 0) // idle + iowait
        val total = parts.sum()
        val dTotal = total - lastCpuTotal
        val dIdle = idle - lastCpuIdle
        lastCpuTotal = total
        lastCpuIdle = idle
        if (dTotal <= 0) return 0
        return ((dTotal - dIdle) * 100 / dTotal).toInt()
    }

    /** GPU 频率（MHz），覆盖高通/MTK/麒麟 */
    private suspend fun readGpuFreq(): Long {
        // 高通 Adreno
        val kgsl = RootShell.readFile("/sys/class/kgsl/kgsl-3d0/gpuclk")
        if (kgsl.isNotBlank()) return kgsl.toLongOrNull()?.div(1_000_000) ?: 0L

        // devfreq GPU
        val devfreq = RootShell.exec(
            "cat /sys/class/devfreq/*gpu*/cur_freq 2>/dev/null | head -1"
        )
        if (devfreq.isNotBlank()) return devfreq.trim().toLongOrNull()?.div(1_000_000) ?: 0L

        // MTK Mali
        val mali = RootShell.exec(
            "cat /sys/class/misc/mali*/device/devfreq/*/cur_freq 2>/dev/null | head -1"
        )
        if (mali.isNotBlank()) return mali.trim().toLongOrNull()?.div(1_000_000) ?: 0L

        // MTK gpufreq dump
        val mtk = RootShell.exec(
            "cat /proc/gpufreq/gpufreq_var_dump 2>/dev/null | grep -m1 'cur_freq'"
        )
        if (mtk.isNotBlank()) {
            val khz = Regex("(\\d+)").find(mtk)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
            return khz / 1000
        }
        return 0L
    }

    /** 电池温度（摄氏度），遍历 thermal_zone 找 battery 类型 */
    private suspend fun readTemperature(): Float {
        // 单次 shell 读取所有 thermal_zone 的 type 和 temp
        val script = """
            for tz in /sys/class/thermal/thermal_zone*; do
                echo "$(cat ${'$'}tz/type 2>/dev/null):$(cat ${'$'}tz/temp 2>/dev/null)"
            done
        """.trimIndent()
        val out = RootShell.exec(script)
        val pairs = out.lines().mapNotNull { line ->
            val idx = line.indexOf(':')
            if (idx <= 0) null
            else line.substring(0, idx).trim() to (line.substring(idx + 1).trim().toLongOrNull() ?: 0L)
        }
        if (pairs.isEmpty()) return 0f
        // 优先 battery 类型，否则取第一个有效温度
        val target = pairs.firstOrNull { (type, _) ->
            type.contains("battery", ignoreCase = true) || type.contains("batt", ignoreCase = true)
        } ?: pairs.firstOrNull { (_, temp) -> temp > 0 }
        return (target?.second ?: 0L) / 1000f
    }
}
