package com.uperf.control.core

import com.uperf.control.root.RootShell

/** 单条应用规则 */
data class AppRule(val packageName: String, val mode: String, val isDefault: Boolean = false, val isOffscreen: Boolean = false)

/**
 * per-app 配置管理器：读写 perapp_powermode.txt。
 * 格式：`包名 模式`，`*` 默认规则，`-` 熄屏规则。
 */
object PerAppManager {

    private const val PERAPP_PATH = "/sdcard/Android/yc/uperf/perapp_powermode.txt"

    /** 读取所有应用规则 */
    suspend fun readRules(): List<AppRule> {
        val content = RootShell.readFile(PERAPP_PATH)
        if (content.isBlank()) return emptyList()
        return content.lines().mapNotNull { line ->
            val trimmed = line.trim()
            if (trimmed.isEmpty() || trimmed.startsWith("#")) return@mapNotNull null
            val parts = trimmed.split(Regex("\\s+"))
            if (parts.size < 2) return@mapNotNull null
            val key = parts[0]
            val mode = parts[1]
            when (key) {
                "*" -> AppRule("*", mode, isDefault = true)
                "-" -> AppRule("-", mode, isOffscreen = true)
                else -> AppRule(key, mode)
            }
        }
    }

    /** 为应用设置模式（不存在则追加，存在则覆盖） */
    suspend fun setRule(packageName: String, mode: String): Boolean {
        val rules = readRules()
        val existing = rules.any { it.packageName == packageName }
        val lines = mutableListOf<String>()
        for (r in rules) {
            if (r.packageName == packageName) {
                lines.add("$packageName $mode")
            } else if (r.isDefault) {
                lines.add("* ${r.mode}")
            } else if (r.isOffscreen) {
                lines.add("- ${r.mode}")
            } else {
                lines.add("${r.packageName} ${r.mode}")
            }
        }
        if (!existing) lines.add("$packageName $mode")
        return writeLines(lines)
    }

    /** 移除应用规则 */
    suspend fun removeRule(packageName: String): Boolean {
        val rules = readRules().filter { it.packageName != packageName }
        return writeLines(rules.map {
            when {
                it.isDefault -> "* ${it.mode}"
                it.isOffscreen -> "- ${it.mode}"
                else -> "${it.packageName} ${it.mode}"
            }
        })
    }

    /** 设置默认规则（* 模式） */
    suspend fun setDefault(mode: String): Boolean {
        val rules = readRules().filter { !it.isDefault }
        val lines = rules.map {
            if (it.isOffscreen) "- ${it.mode}" else "${it.packageName} ${it.mode}"
        } + "* $mode"
        return writeLines(lines)
    }

    private suspend fun writeLines(lines: List<String>): Boolean {
        val content = lines.joinToString("\n") + "\n"
        return RootShell.execOk("echo '$content' > $PERAPP_PATH")
    }
}
