package com.uperf.control.core

import com.uperf.control.root.RootShell
import org.json.JSONObject

/** 性能模式定义，与 Uperf 的 powercfg 接口对齐 */
enum class PowerMode(val cmd: String, val label: String) {
    POWERSAVE("powersave", "省电"),
    BALANCE("balance", "均衡"),
    PERFORMANCE("performance", "性能"),
    FAST("fast", "极速"),
    PEDESTAL("pedestal", "狂暴");

    companion object {
        fun fromCmd(cmd: String): PowerMode? = when (cmd.trim()) {
            "powersave" -> POWERSAVE
            "balance" -> BALANCE
            "performance" -> PERFORMANCE
            "fast" -> FAST
            "pedestal", "crazy" -> PEDESTAL
            else -> null
        }
    }
}

/** powercfg.json 解析结果 */
data class PowerConfig(
    val entry: String,
    val state: String,
    val supportsPedestal: Boolean,
)

/**
 * 模式管理器：解析 /data/powercfg.json，切换模式，读取当前状态。
 */
object PowerModeManager {

    // 默认配置路径（Uperf 模块安装后生成）
    private const val CFG_PATH = "/data/powercfg.json"
    private const val DEFAULT_STATE = "/sdcard/Android/yc/uperf/cur_powermode.txt"
    private const val DEFAULT_ENTRY = "/data/powercfg.sh"

    /** 加载 powercfg 配置 */
    suspend fun loadConfig(): PowerConfig? {
        val json = RootShell.readFile(CFG_PATH)
        if (json.isBlank()) return null
        return try {
            val obj = JSONObject(json)
            val entry = obj.optString("entry", DEFAULT_ENTRY)
            val state = obj.optString("state", DEFAULT_STATE)
            val features = obj.optJSONObject("features")
            val pedestal = features?.optBoolean("pedestal", false) ?: false
            PowerConfig(entry = entry, state = state, supportsPedestal = pedestal)
        } catch (e: Exception) {
            null
        }
    }

    /** 切换模式 */
    suspend fun setMode(config: PowerConfig?, mode: PowerMode): Boolean {
        val entry = config?.entry ?: DEFAULT_ENTRY
        return RootShell.execOk("sh $entry ${mode.cmd}")
    }

    /** 读取当前模式 */
    suspend fun currentMode(config: PowerConfig?): PowerMode? {
        val state = config?.state ?: DEFAULT_STATE
        val cmd = RootShell.readFile(state)
        return PowerMode.fromCmd(cmd)
    }

    /** 手动触发 turbo_boost 极限调优脚本 */
    suspend fun runTurboBoost(): Boolean {
        return RootShell.execOk(
            "sh /data/adb/modules/uperf/script/turbo_boost.sh"
        )
    }

    /** 检查 Uperf 模块是否已安装 */
    suspend fun isUperfInstalled(): Boolean {
        val cfg = RootShell.readFile(CFG_PATH)
        return cfg.isNotBlank()
    }
}
