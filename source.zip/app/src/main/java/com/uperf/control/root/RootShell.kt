package com.uperf.control.root

import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Root shell 交互层，统一封装 libsu。
 * 所有命令在 IO 线程执行，返回 stdout 文本。
 */
object RootShell {

    /** 是否已获得 root 权限 */
    suspend fun isRoot(): Boolean = withContext(Dispatchers.IO) {
        try {
            Shell.getShell().isRoot
        } catch (e: Exception) {
            false
        }
    }

    /** 同步执行命令（IO 线程），返回 stdout */
    suspend fun exec(cmd: String): String = withContext(Dispatchers.IO) {
        val result = Shell.cmd(cmd).exec()
        result.out.joinToString("\n")
    }

    /** 执行多条命令 */
    suspend fun exec(vararg cmds: String): String = withContext(Dispatchers.IO) {
        val result = Shell.cmd(*cmds).exec()
        result.out.joinToString("\n")
    }

    /** 执行命令并返回是否成功 */
    suspend fun execOk(cmd: String): Boolean = withContext(Dispatchers.IO) {
        Shell.cmd(cmd).exec().isSuccess
    }

    /** 读取单个文件内容（root） */
    suspend fun readFile(path: String): String = withContext(Dispatchers.IO) {
        Shell.cmd("cat $path 2>/dev/null").exec().out.firstOrNull()?.trim() ?: ""
    }

    /** 读取多个文件，返回 path -> value 映射（单次 shell 批量读取） */
    suspend fun readFiles(paths: List<String>): Map<String, String> = withContext(Dispatchers.IO) {
        if (paths.isEmpty()) return@withContext emptyMap()
        val script = paths.joinToString("\n") { p ->
            "echo \"$p=\$(cat $p 2>/dev/null)\""
        }
        val result = Shell.cmd(script).exec()
        val map = mutableMapOf<String, String>()
        for (line in result.out) {
            val idx = line.indexOf('=')
            if (idx > 0) {
                map[line.substring(0, idx)] = line.substring(idx + 1).trim()
            }
        }
        map
    }

    /** 写值到文件（root，写后恢复权限） */
    suspend fun writeFile(path: String, value: String): Boolean = withContext(Dispatchers.IO) {
        Shell.cmd("echo '$value' > $path 2>/dev/null").exec().isSuccess
    }
}
