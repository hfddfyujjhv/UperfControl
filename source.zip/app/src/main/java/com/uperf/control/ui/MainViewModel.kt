package com.uperf.control.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.uperf.control.core.MonitorManager
import com.uperf.control.core.PowerConfig
import com.uperf.control.core.PowerMode
import com.uperf.control.core.PowerModeManager
import com.uperf.control.root.RootShell
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {

    private val _isRoot = MutableStateFlow(false)
    val isRoot: StateFlow<Boolean> = _isRoot.asStateFlow()

    private val _config = MutableStateFlow<PowerConfig?>(null)
    val config: StateFlow<PowerConfig?> = _config.asStateFlow()

    private val _currentMode = MutableStateFlow<PowerMode?>(null)
    val currentMode: StateFlow<PowerMode?> = _currentMode.asStateFlow()

    private val _uperfInstalled = MutableStateFlow(false)
    val uperfInstalled: StateFlow<Boolean> = _uperfInstalled.asStateFlow()

    val monitor = MonitorManager.snapshot

    private var monitorJob: Job? = null

    init {
        refresh()
    }

    /** 刷新 root 状态、配置、当前模式 */
    fun refresh() {
        viewModelScope.launch {
            _isRoot.value = RootShell.isRoot()
            _uperfInstalled.value = PowerModeManager.isUperfInstalled()
            _config.value = PowerModeManager.loadConfig()
            _currentMode.value = PowerModeManager.currentMode(_config.value)
        }
    }

    /** 切换模式 */
    fun setMode(mode: PowerMode) {
        viewModelScope.launch {
            if (PowerModeManager.setMode(_config.value, mode)) {
                _currentMode.value = mode
            }
        }
    }

    /** 触发 turbo_boost */
    fun runTurboBoost(onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = PowerModeManager.runTurboBoost()
            onDone(ok)
        }
    }

    /** 启动监控循环（1s 刷新） */
    fun startMonitor() {
        if (monitorJob != null) return
        monitorJob = viewModelScope.launch {
            while (true) {
                MonitorManager.poll()
                delay(1000)
            }
        }
    }

    /** 停止监控循环 */
    fun stopMonitor() {
        monitorJob?.cancel()
        monitorJob = null
    }
}
