package com.uperf.control.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.uperf.control.core.PowerMode

@Composable
fun ModeScreen(viewModel: MainViewModel, modifier: Modifier = Modifier) {
    val isRoot by viewModel.isRoot.collectAsState()
    val uperfInstalled by viewModel.uperfInstalled.collectAsState()
    val currentMode by viewModel.currentMode.collectAsState()
    val config by viewModel.config.collectAsState()

    Column(modifier = modifier.fillMaxWidth()) {
        // 状态横幅
        StatusBanner(isRoot, uperfInstalled)

        val modes = PowerMode.entries.filter { mode ->
            mode != PowerMode.PEDESTAL || (config?.supportsPedestal == true)
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            items(modes) { mode ->
                ModeCard(
                    mode = mode,
                    selected = currentMode == mode,
                    enabled = isRoot && uperfInstalled,
                    onClick = { viewModel.setMode(mode) }
                )
            }
        }
    }
}

@Composable
private fun StatusBanner(isRoot: Boolean, uperfInstalled: Boolean) {
    val statusText = when {
        !isRoot -> "未获取 root 权限"
        !uperfInstalled -> "未检测到 Uperf 模块"
        else -> "就绪"
    }
    val color = when {
        !isRoot || !uperfInstalled -> MaterialTheme.colorScheme.error
        else -> MaterialTheme.colorScheme.primary
    }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = color)
    ) {
        Text(
            text = statusText,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(16.dp),
            color = MaterialTheme.colorScheme.onPrimary
        )
    }
}

@Composable
private fun ModeCard(
    mode: PowerMode,
    selected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    val containerColor = if (selected) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.colorScheme.surfaceVariant
    }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(enabled = enabled, onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = containerColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = mode.label,
                style = MaterialTheme.typography.titleLarge,
                color = if (selected) MaterialTheme.colorScheme.onPrimary
                else MaterialTheme.colorScheme.onSurface
            )
            if (selected) {
                Text(
                    text = "● 当前",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            }
        }
    }
}
