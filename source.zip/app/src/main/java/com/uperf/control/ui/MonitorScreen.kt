package com.uperf.control.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.uperf.control.core.CpuCoreFreq
import java.util.Locale

@Composable
fun MonitorScreen(viewModel: MainViewModel, modifier: Modifier = Modifier) {
    val snapshot by viewModel.monitor.collectAsState()

    DisposableEffect(Unit) {
        viewModel.startMonitor()
        onDispose { viewModel.stopMonitor() }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 概览卡片
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("CPU 负载 ${snapshot.cpuLoad}%", style = MaterialTheme.typography.titleMedium)
                LinearProgressIndicator(
                    progress = { snapshot.cpuLoad / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("GPU ${snapshot.gpuFreqMHz} MHz")
                    Text(String.format(Locale.US, "温度 %.1f ℃", snapshot.temperatureC))
                }
            }
        }

        // 各核频率
        Text("核心频率", style = MaterialTheme.typography.titleMedium)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(snapshot.cpuFreqs) { core ->
                CoreFreqCard(core)
            }
        }
    }
}

@Composable
private fun CoreFreqCard(core: CpuCoreFreq) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("核${core.core}", style = MaterialTheme.typography.labelMedium)
            Text(
                text = if (core.freqKHz > 0) "${core.freqKHz / 1000} MHz" else "--",
                style = MaterialTheme.typography.titleSmall
            )
        }
    }
}
