package com.uperf.control.ui

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.uperf.control.core.AppRule
import com.uperf.control.core.PerAppManager
import com.uperf.control.core.PowerMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class AppInfo(val packageName: String, val label: String)

@Composable
fun PerAppScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var rules by remember { mutableStateOf<List<AppRule>>(emptyList()) }
    var selectedApp by remember { mutableStateOf<AppInfo?>(null) }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) { loadUserApps(context) }
        rules = PerAppManager.readRules()
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = "应用性能模式（点击应用设置）",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(16.dp)
        )
        LazyColumn(modifier = Modifier.fillMaxWidth()) {
            items(apps, key = { it.packageName }) { app ->
                val rule = rules.firstOrNull { it.packageName == app.packageName }
                AppRow(
                    app = app,
                    modeLabel = rule?.let { r -> PowerMode.fromCmd(r.mode)?.label },
                    onClick = { selectedApp = app }
                )
            }
        }
    }

    selectedApp?.let { app ->
        ModePickerDialog(
            app = app,
            onDismiss = { selectedApp = null },
            onSelect = { mode ->
                scope.launch {
                    if (mode == null) {
                        PerAppManager.removeRule(app.packageName)
                    } else {
                        PerAppManager.setRule(app.packageName, mode.cmd)
                    }
                    rules = PerAppManager.readRules()
                    selectedApp = null
                }
            }
        )
    }
}

private suspend fun loadUserApps(context: android.content.Context): List<AppInfo> {
    val pm = context.packageManager
    val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
    return apps
        .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 || hasLauncherIntent(pm, it.packageName) }
        .filter { hasLauncherIntent(pm, it.packageName) }
        .map { AppInfo(it.packageName, pm.getApplicationLabel(it).toString()) }
        .sortedBy { it.label }
}

private fun hasLauncherIntent(pm: PackageManager, packageName: String): Boolean {
    val intent = android.content.Intent(android.content.Intent.ACTION_MAIN).apply {
        addCategory(android.content.Intent.CATEGORY_LAUNCHER)
        setPackage(packageName)
    }
    return pm.queryIntentActivities(intent, 0).isNotEmpty()
}

@Composable
private fun AppRow(app: AppInfo, modeLabel: String?, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(app.label, style = MaterialTheme.typography.bodyLarge)
                Text(
                    app.packageName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                text = modeLabel ?: "默认",
                style = MaterialTheme.typography.bodyMedium,
                color = if (modeLabel != null) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ModePickerDialog(
    app: AppInfo,
    onDismiss: () -> Unit,
    onSelect: (PowerMode?) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("选择模式：${app.label}") },
        text = {
            Column {
                PowerMode.entries.forEach { mode ->
                    TextButton(
                        onClick = { onSelect(mode) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(mode.label, modifier = Modifier.fillMaxWidth())
                    }
                }
                TextButton(
                    onClick = { onSelect(null) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("恢复默认", modifier = Modifier.fillMaxWidth())
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("取消") }
        }
    )
}
