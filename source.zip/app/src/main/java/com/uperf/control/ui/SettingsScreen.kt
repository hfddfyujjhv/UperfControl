package com.uperf.control.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.uperf.control.overlay.OverlayService

@Composable
fun SettingsScreen(viewModel: MainViewModel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val isRoot by viewModel.isRoot.collectAsState()
    val uperfInstalled by viewModel.uperfInstalled.collectAsState()

    var overlayOn by remember { mutableStateOf(false) }
    var turboMsg by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 状态卡片
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                InfoRow("Root 权限", if (isRoot) "已获取" else "未获取")
                InfoRow("Uperf 模块", if (uperfInstalled) "已安装" else "未安装")
            }
        }

        // 悬浮窗开关
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("性能悬浮窗", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "游戏内显示 FPS/频率/温度",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Switch(
                    checked = overlayOn,
                    onCheckedChange = { checked ->
                        overlayOn = checked
                        if (checked) {
                            if (Settings.canDrawOverlays(context)) {
                                OverlayService.start(context)
                            } else {
                                overlayOn = false
                                val intent = Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                )
                                context.startActivity(intent)
                            }
                        } else {
                            OverlayService.stop(context)
                        }
                    }
                )
            }
        }

        // Turbo Boost
        Button(
            onClick = {
                viewModel.runTurboBoost { ok ->
                    turboMsg = if (ok) "turbo_boost 已执行" else "执行失败"
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("触发 Turbo Boost 极限调优")
        }
        turboMsg?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium)
        }

        // 刷新
        Button(
            onClick = { viewModel.refresh() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("刷新状态")
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Text(
            value,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.primary
        )
    }
}
